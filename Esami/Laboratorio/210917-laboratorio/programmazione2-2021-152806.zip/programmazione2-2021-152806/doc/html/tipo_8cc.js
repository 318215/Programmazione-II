var tipo_8cc =
[
    [ "compare", "tipo_8cc.html#a0e3ec8f73abb534535ced21f74f65533", null ],
    [ "copy", "tipo_8cc.html#a7a742bcda43816cd279df6820132bb8d", null ],
    [ "print", "tipo_8cc.html#af5392bbac3bda30b7b5c2e033f7878a4", null ]
];