var annotated_dup =
[
    [ "elem", "structelem.html", "structelem" ],
    [ "tipo_inf", "structtipo__inf.html", "structtipo__inf" ]
];