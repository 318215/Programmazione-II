var structtipo__inf =
[
    [ "data", "structtipo__inf.html#ade459bd01129385e61f56f39739d2a13", null ],
    [ "descr", "structtipo__inf.html#a97a42b5f9c3af10219647bf7cee08854", null ],
    [ "oraFine", "structtipo__inf.html#a537cbc52437d292db3e4557e12421880", null ],
    [ "oraInizio", "structtipo__inf.html#a36236882dfee7ec19ebd163e33fd8be1", null ]
];