var searchData=
[
  ['tipo_5finf_31',['tipo_inf',['../structtipo__inf.html',1,'']]]
];
