var searchData=
[
  ['compare_2',['compare',['../tipo_8cc.html#a0e3ec8f73abb534535ced21f74f65533',1,'compare(tipo_inf a1, tipo_inf a2):&#160;tipo.cc'],['../tipo_8h.html#abaf6df3b59219b4f9a01bceaa9a7ac65',1,'compare(tipo_inf, tipo_inf):&#160;tipo.cc']]],
  ['compito_2ecc_3',['compito.cc',['../compito_8cc.html',1,'']]],
  ['copy_4',['copy',['../tipo_8cc.html#a7a742bcda43816cd279df6820132bb8d',1,'copy(tipo_inf &amp;a1, tipo_inf a2):&#160;tipo.cc'],['../tipo_8h.html#a5b601e34d40349d965e34c2dcc79ce1f',1,'copy(tipo_inf &amp;, tipo_inf):&#160;tipo.cc']]]
];
