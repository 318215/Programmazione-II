var searchData=
[
  ['agenda_37',['agenda',['../compito_8cc.html#a4224ea26a614aaa1a0bb2a056c51f414',1,'compito.cc']]]
];
