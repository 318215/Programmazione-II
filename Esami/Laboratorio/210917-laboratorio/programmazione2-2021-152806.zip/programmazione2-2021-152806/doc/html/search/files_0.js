var searchData=
[
  ['compito_2ecc_32',['compito.cc',['../compito_8cc.html',1,'']]]
];
