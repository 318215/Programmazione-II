var searchData=
[
  ['data_52',['data',['../structtipo__inf.html#ade459bd01129385e61f56f39739d2a13',1,'tipo_inf']]],
  ['descr_53',['descr',['../structtipo__inf.html#a97a42b5f9c3af10219647bf7cee08854',1,'tipo_inf']]]
];
