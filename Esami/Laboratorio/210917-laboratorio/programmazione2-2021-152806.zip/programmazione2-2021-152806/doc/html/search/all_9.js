var searchData=
[
  ['orafine_17',['oraFine',['../structtipo__inf.html#a537cbc52437d292db3e4557e12421880',1,'tipo_inf']]],
  ['orainizio_18',['oraInizio',['../structtipo__inf.html#a36236882dfee7ec19ebd163e33fd8be1',1,'tipo_inf']]],
  ['ord_5finsert_5felem_19',['ord_insert_elem',['../liste_8cc.html#a0bb6e8fcf66699f37d008d5562946d37',1,'ord_insert_elem(lista l, elem *e):&#160;liste.cc'],['../liste_8h.html#ac9b0abee054a39ed2ce08eee4a940349',1,'ord_insert_elem(lista, elem *):&#160;liste.cc']]]
];
