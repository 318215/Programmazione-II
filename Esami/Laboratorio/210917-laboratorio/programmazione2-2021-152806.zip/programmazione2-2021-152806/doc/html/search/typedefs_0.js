var searchData=
[
  ['appuntamento_59',['appuntamento',['../tipo_8h.html#aaddd544d82cb9769e4e03d61dc926022',1,'tipo.h']]]
];
