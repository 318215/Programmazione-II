var searchData=
[
  ['inf_54',['inf',['../structelem.html#afe1cd47c775cae94eb1363734bace411',1,'elem']]]
];
