var searchData=
[
  ['ord_5finsert_5felem_45',['ord_insert_elem',['../liste_8cc.html#a0bb6e8fcf66699f37d008d5562946d37',1,'ord_insert_elem(lista l, elem *e):&#160;liste.cc'],['../liste_8h.html#ac9b0abee054a39ed2ce08eee4a940349',1,'ord_insert_elem(lista, elem *):&#160;liste.cc']]]
];
