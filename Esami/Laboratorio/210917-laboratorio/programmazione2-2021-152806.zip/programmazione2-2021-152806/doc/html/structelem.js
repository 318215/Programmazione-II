var structelem =
[
    [ "inf", "structelem.html#afe1cd47c775cae94eb1363734bace411", null ],
    [ "prev", "structelem.html#a9d914201f1b505801ec2c812ca6e8630", null ],
    [ "pun", "structelem.html#a5676f3bc339c6078388c93534e0ddbb2", null ]
];