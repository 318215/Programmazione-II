var compito_8cc =
[
    [ "agenda", "compito_8cc.html#a4224ea26a614aaa1a0bb2a056c51f414", null ],
    [ "main", "compito_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "quanti", "compito_8cc.html#a7d98ff43ab295662b79266f657760936", null ],
    [ "stampa", "compito_8cc.html#a07e15f0019f90fbd94812a723766a51b", null ]
];