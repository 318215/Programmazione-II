var searchData=
[
  ['compare_36',['compare',['../tipo_8cc.html#aca9696962783fbe612428ee7e991ce75',1,'compare(tipo_inf a, tipo_inf b):&#160;tipo.cc'],['../tipo_8h.html#abaf6df3b59219b4f9a01bceaa9a7ac65',1,'compare(tipo_inf, tipo_inf):&#160;tipo.cc']]],
  ['copy_37',['copy',['../tipo_8cc.html#a780d7635e64a79222bb506ed6e9f72f0',1,'copy(tipo_inf &amp;dest, tipo_inf src):&#160;tipo.cc'],['../tipo_8h.html#a5b601e34d40349d965e34c2dcc79ce1f',1,'copy(tipo_inf &amp;, tipo_inf):&#160;tipo.cc']]]
];
