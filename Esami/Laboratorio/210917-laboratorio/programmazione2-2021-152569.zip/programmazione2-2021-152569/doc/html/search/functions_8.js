var searchData=
[
  ['quanti_45',['quanti',['../compito_8cc.html#a7d98ff43ab295662b79266f657760936',1,'compito.cc']]]
];
