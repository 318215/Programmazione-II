var searchData=
[
  ['oraf_52',['oraf',['../structtipo__inf.html#ad2b02884ca7cf9aa524982362d4e5d10',1,'tipo_inf']]],
  ['orai_53',['orai',['../structtipo__inf.html#ae2d4843e645d9f311239693304a1f610',1,'tipo_inf']]]
];
