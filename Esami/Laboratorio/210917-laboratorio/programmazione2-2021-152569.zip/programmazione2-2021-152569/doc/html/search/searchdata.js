var indexSectionsWithContent =
{
  0: "acdehilmnopqst",
  1: "et",
  2: "clt",
  3: "acdhimnpqst",
  4: "diop",
  5: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Ridefinizioni di tipo (typedef)"
};

