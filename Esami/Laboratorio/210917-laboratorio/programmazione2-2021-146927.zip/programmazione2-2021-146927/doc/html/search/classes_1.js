var searchData=
[
  ['tipo_5finf_29',['tipo_inf',['../structtipo__inf.html',1,'']]]
];
