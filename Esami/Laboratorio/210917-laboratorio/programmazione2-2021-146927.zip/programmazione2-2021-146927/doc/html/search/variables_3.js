var searchData=
[
  ['prev_54',['prev',['../structelem.html#a9d914201f1b505801ec2c812ca6e8630',1,'elem']]],
  ['pun_55',['pun',['../structelem.html#a5676f3bc339c6078388c93534e0ddbb2',1,'elem']]]
];
