var searchData=
[
  ['tipo_2ecc_33',['tipo.cc',['../tipo_8cc.html',1,'']]],
  ['tipo_2eh_34',['tipo.h',['../tipo_8h.html',1,'']]]
];
