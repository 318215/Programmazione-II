var searchData=
[
  ['inf_51',['inf',['../structelem.html#afe1cd47c775cae94eb1363734bace411',1,'elem']]]
];
